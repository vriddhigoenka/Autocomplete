import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashListAutocomplete implements Autocompletor {

    private static final int MAX_PREFIX = 10;
    private Map<String, List<Term>> myMap;
    private int mySize;

    public HashListAutocomplete(String[] terms, double[] weights) {

        if (terms == null || weights == null) {
			throw new NullPointerException("One or more arguments null");
		}

        if (terms.length != weights.length) {
			throw new IllegalArgumentException("terms and weights are not the same length");
		}
		
		initialize(terms,weights);
    }

    @Override
    public List<Term> topMatches(String prefix, int k) {
    
        if(prefix.length() > MAX_PREFIX)
            prefix = prefix.substring(0, MAX_PREFIX);
        
        if(myMap.containsKey(prefix)){
            List<Term> full = myMap.get(prefix);
            List<Term> partial = full.subList(0, Math.min(k, full.size()));
            return partial;
        }

        return new ArrayList<>(); 
    }

    @Override
    public void initialize(String[] terms, double[] weights) {
        myMap = new HashMap<String, List<Term>>();
		for (int i = 0; i < terms.length; i++) {
			int min = Math.min(MAX_PREFIX, terms[i].length());
			for (int k = 0; k <= min; k++) {
				if (!myMap.containsKey(terms[i].substring(0, k))) { 
					List<Term> newlist = new ArrayList<Term>();
					Term curr = new Term(terms[i], weights[i]);
					myMap.put(terms[i].substring(0, k), newlist);
					myMap.get(terms[i].substring(0, k)).add(curr);
				} 
                else{
                    Term curr = new Term(terms[i], weights[i]);
					myMap.get(terms[i].substring(0, k)).add(curr);
				}

				if(weights[i] < 0) {
					throw new IllegalArgumentException("Weight below 0");
				}
			}
		}

		for (String s : myMap.keySet()) {
			Collections.sort(myMap.get(s), Comparator.comparing(Term::getWeight).reversed());
		}
		mySize = 0;
        
    }

    @Override
    public int sizeInBytes() {
        if(mySize == 0){
			for (String s : myMap.keySet()) {
                int val = 0;
				mySize = mySize + s.length() * BYTES_PER_CHAR;
				List<Term> b = myMap.get(s);
				while (val < b.size()) {
					Term given = b.get(val);
					mySize = mySize + BYTES_PER_DOUBLE + BYTES_PER_CHAR * given.getWord().length();
					val++;
				}
			}
		}

		return mySize;
    }  
}

